//
//  AddPhotoCollectionViewCell.h
//  documentary-video-ios-native
//
//  Created by Bibo on 4/16/15.
//  Copyright (c) 2015 Bibo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddPhotoCollectionViewCell : UICollectionViewCell


@property (nonatomic, strong) UIImageView *photoImageView;
@property (nonatomic, strong) UIImageView *imageCheckMark;

@end
