//
//  AppDelegate.h
//  documentary-video-ios-native
//
//  Created by Bibo on 3/29/15.
//  Copyright (c) 2015 Bibo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

